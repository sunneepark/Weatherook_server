module.exports = {
    secret : "Weather look Server Girls"
}